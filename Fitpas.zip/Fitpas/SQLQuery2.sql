﻿select * FROM [Paket-Teretana] pt JOIN Teretana t ON pt.idTeretane = t.idTeretane 
WHERE pt.idPaketa = 1