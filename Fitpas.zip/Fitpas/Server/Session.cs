﻿using Common.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
  
        internal static class Session
        {
            public static List<ClientHandler> clientHandlers = new List<ClientHandler>();
            
            
          

        }
    
}
